# Body-Mass-Index-BMI-Calculator
Body Mass Index (BMI) Calculator using HTML CSS  JAVASCRIPT.
BMI Calculator takes height and weight as inputs from user and shows BMI and Weight Condition as Under Weight or Normal Weight or Over Weight or Obesity.
![Screenshot (127)](https://github.com/AKASHNEGI-github/Body-Mass-Index-BMI-Calculator/assets/136436720/586db284-a59a-42be-bccc-385c0d166ae8)
